<?php

namespace Source\Core;

class Controller
{
    protected View $view;

    /**
     * Controller constructor.
     * @param string|null $pathToViews
     */
    public function __construct(string $pathToViews = null)
    {
        $this->view = new View($pathToViews);
    }
}
